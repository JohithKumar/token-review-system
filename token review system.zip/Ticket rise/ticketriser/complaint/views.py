from django.shortcuts import render, redirect
from urllib import request
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Complaint
from .serializer import ComplaintSerializer
from rest_framework.pagination import PageNumberPagination
from django.contrib.auth import authenticate
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import permission_classes
from django.views.decorators.cache import cache_page  
from django.utils.decorators import method_decorator
@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])  
@cache_page(60 * 15)  # Cache for 60 seconds (1 minute)
def complaint_list(request):
    if request.method == 'GET':
        ordering = request.query_params.get('ordering')
        search = request.query_params.get('search')
        complaints = Complaint.objects.all()
        title = request.query_params.get('title')
        category = request.query_params.get('category')
        if search:
            complaints = complaints.filter(title__icontains=search)
        if category:
            complaints = complaints.filter(category=category)
        if ordering:
            complaints = complaints.order_by(ordering)
        paginator = PageNumberPagination()
        paginator.page_size = 2
        paginated_complaints = paginator.paginate_queryset(complaints, request)
        serializer = ComplaintSerializer(paginated_complaints, many=True)
        return paginator.get_paginated_response(serializer.data)
    if request.method == 'POST':
        serializer = ComplaintSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)
@api_view(['GET', 'PUT', 'DELETE', 'PATCH'])
@permission_classes([IsAuthenticated])
@cache_page(60 * 15)  # Cache for 60 seconds (1 minute)
def complaint_detail(request, id):
    try:
        complaint = Complaint.objects.get(id=id)
    except Complaint.DoesNotExist:
        return Response(status=404)
    if request.method == 'GET':
        serializer = ComplaintSerializer(complaint)
        return Response(serializer.data)
    if request.method == 'PUT':
        serializer = ComplaintSerializer(complaint, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=400)
    if request.method == 'DELETE':
        complaint.delete()
        return Response(status=204)
    if request.method == 'PATCH':
        serializer = ComplaintSerializer(complaint, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=400)
def index(request):
    complaints = Complaint.objects.all()
    return render(request, 'complaint/index.html', {'complaints': complaints})
def detail(request, id):
    item = Complaint.objects.get(id=id)
    return render(request, 'complaint/detail.html', {'item': item})
def edit(request, id):
    item = Complaint.objects.get(id=id)
    if request.method == 'POST':
        item.title = request.POST.get('title')
        item.category = request.POST.get('category')
        item.save()
        return redirect('home')
    return render(request, 'complaint/edit.html', {'item': item})
def delete(request, id):
    item = Complaint.objects.get(id=id)
    if request.method == 'POST':
        item.delete()
        return redirect('home')
    return render(request, 'complaint/delete.html', {'item': item})